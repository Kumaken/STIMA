# Simple-Chat-NLP
Basic NLP in python with KMP, Booyer-Moore, and Regex algorithms
